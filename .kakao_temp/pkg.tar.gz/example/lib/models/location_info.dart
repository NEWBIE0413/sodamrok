import 'package:kakao_map_sdk/kakao_map_sdk.dart';

class LocationInfo {
  final String name;
  final LatLng position;

  LocationInfo(this.name, this.position);
}
