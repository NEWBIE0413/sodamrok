package kr.yhs.flutter_kakao_map_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
