package kr.yhs.flutter_kakao_maps_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
