part of '../../kakao_map_sdk.dart';

abstract class DefaultGUI {
  DefaultGUIType get type;
}
