package kr.yhs.flutter_kakao_maps.model

enum class DefaultGUIType(val value: String) {
  compass("compass"),
  scale("scale"),
  logo("logo"),
}
