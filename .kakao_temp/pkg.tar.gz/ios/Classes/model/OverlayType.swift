enum OverlayType: Int {
    case label = 1, lodLabel, shape, route
}
