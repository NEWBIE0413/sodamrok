enum DefaultGUIType: String {
    case compass
    case scale
    case logo
}
